$(document).on('pagecreate',function(){

$("#newButton").on('click', function(event) {
	if(event.handled !== true) // prevents event triggering more than once
	{
	$("#to-do-list").append("<li>" + $("#what-to-do").val()+": Pending" + "</li>").listview("refresh");
	$("#what-to-do").val('');
	event.handled = true;
	}
});

$(document).on('click', "#to-do-list li", function(event){
	if(event.handled !== true) // prevents event triggering more than once
	{
	var listitem = $( this );
	$("#done-list").append("<li>" + listitem.text().replace(": Pending",": Notification Sent") + "</li>").listview("refresh");
	//listitem.remove();
	$("#to-do-list").listview("refresh");
	event.handled=true;
	//increaseScore();
	}
});

});
/*
function increaseScore() {
	if(typeof(Storage) != "undefined") {
		var myScore = localStorage.getItem("score");
		if (myScore != 'undefined') {
			myScore++;
		} else {
			myScore = 1;
		}
		try {
			localStorage.setItem("score",myScore);
		}
		catch(e) {
			alert("Score storage failed.");
		}
	} else {
		alert("no web storage support.");
	}
}
*/
/*function getScore() {
	if(typeof(Storage) !== "undefined") {
		return localStorage.getItem("score");
	}
}
*/
/*function displayScore() {
	var myScore = getScore();
	if (myScore == 'undefined') {
		myScore = 0;
	}
	$('#showScore').html(myScore);
}
*/
/*
$(document).on('pagebeforeshow', '#score', function(){
	displayScore();
});
*/
